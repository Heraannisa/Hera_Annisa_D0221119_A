package javapointofsale;
public class Barang {
    int id;
String namaBarang;
int stokBarang, hargaBarang, terjual;

    public Barang(int id, String namaBarang, int stokBarang, int hargaBarang, int terjual){
        this.id = id;
        this.namaBarang = namaBarang;
        this.stokBarang = stokBarang;
        this.hargaBarang = hargaBarang;
        this.terjual = terjual;
    }
}
